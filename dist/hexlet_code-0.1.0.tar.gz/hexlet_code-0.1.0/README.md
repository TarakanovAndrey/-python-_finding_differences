### Hexlet tests and linter status:
[![Actions Status](https://github.com/TarakanovAndrey/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/TarakanovAndrey/python-project-50/actions)  

[![Python CI](https://github.com/TarakanovAndrey/python-project-50/actions/workflows/tarakanov-check.yml/badge.svg)](https://github.com/TarakanovAndrey/python-project-50/actions/workflows/tarakanov-check.yml)  

<a href="https://codeclimate.com/github/TarakanovAndrey/python-project-50/maintainability"><img src="https://api.codeclimate.com/v1/badges/16787555bd5efca240e9/maintainability" /></a>  

[![Test Coverage](https://api.codeclimate.com/v1/badges/16787555bd5efca240e9/test_coverage)](https://codeclimate.com/github/TarakanovAndrey/python-project-50/test_coverage)  

