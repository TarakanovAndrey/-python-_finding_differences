### Hexlet tests and linter status:
[![Actions Status](https://github.com/TarakanovAndrey/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/TarakanovAndrey/python-project-50/actions)

[![asciicast](https://asciinema.org/a/vF8hqUTmeIzFBR7iamowhLv1S.svg)](https://asciinema.org/a/vF8hqUTmeIzFBR7iamowhLv1S)
