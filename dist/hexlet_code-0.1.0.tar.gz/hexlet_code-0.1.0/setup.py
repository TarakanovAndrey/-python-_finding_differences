# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gendiff', 'gendiff.auxiliary', 'gendiff.formatting', 'gendiff.scripts']

package_data = \
{'': ['*'], 'gendiff': ['files/*']}

install_requires = \
['flake8>=5.0.4,<6.0.0',
 'pytest>=7.3.1,<8.0.0',
 'yaml @ '
 'file:///home/smallniels/Documents/python-project-50/dist/PyYAML-6.0-cp310-cp310-manylinux_2_5_x86_64.manylinux1_x86_64.manylinux_2_12_x86_64.manylinux2010_x86_64.whl']

entry_points = \
{'console_scripts': ['gendiff = gendiff.scripts.gendiff:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'Comparison of the original and the modified document in json or yml format and output of differences.',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/TarakanovAndrey/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/TarakanovAndrey/python-project-50/actions)  \n\n[![Python CI](https://github.com/TarakanovAndrey/python-project-50/actions/workflows/tarakanov-check.yml/badge.svg)](https://github.com/TarakanovAndrey/python-project-50/actions/workflows/tarakanov-check.yml)  \n\n<a href="https://codeclimate.com/github/TarakanovAndrey/python-project-50/maintainability"><img src="https://api.codeclimate.com/v1/badges/16787555bd5efca240e9/maintainability" /></a>  \n\n[![Test Coverage](https://api.codeclimate.com/v1/badges/16787555bd5efca240e9/test_coverage)](https://codeclimate.com/github/TarakanovAndrey/python-project-50/test_coverage)  \n\n',
    'author': 'Andrey_Tarakanov',
    'author_email': 'andrey.t-krd@yandex.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
