from gendiff.generate_diff import generate_diff  # noqa F401


__all__ = 'generate_diff'
